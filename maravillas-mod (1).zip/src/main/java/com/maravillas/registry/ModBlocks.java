package com.maravillas.registry;

import com.maravillas.MaravillasMod;
import java.util.function.Supplier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.GlassBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Los bloques de construccion de cada estructura: ladrillos, un bloque especial y una lampara. */
public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MaravillasMod.MODID);
    public static final DeferredRegister<Item> BLOCK_ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MaravillasMod.MODID);

    // ---- Torre Estelar ----
    public static final RegistryObject<Block> STAR_BRICKS = brick("star_bricks", MapColor.COLOR_PURPLE);
    public static final RegistryObject<Block> STAR_GLASS = block("star_glass", () -> new GlassBlock(
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(0.5F)
                    .sound(SoundType.GLASS).noOcclusion().lightLevel(state -> 6)));
    public static final RegistryObject<Block> STAR_LAMP = lamp("star_lamp", MapColor.COLOR_YELLOW);

    // ---- Ciudadela Celeste ----
    public static final RegistryObject<Block> CLOUD_BRICKS = brick("cloud_bricks", MapColor.SNOW);
    public static final RegistryObject<Block> CLOUD_BLOCK = block("cloud_block", () -> new Block(
            BlockBehaviour.Properties.of().mapColor(MapColor.SNOW).strength(0.4F).sound(SoundType.WOOL)));
    public static final RegistryObject<Block> SKY_LAMP = lamp("sky_lamp", MapColor.COLOR_LIGHT_BLUE);

    // ---- Templo Hundido ----
    public static final RegistryObject<Block> ABYSS_BRICKS = brick("abyss_bricks", MapColor.COLOR_CYAN);
    public static final RegistryObject<Block> ABYSS_CHISELED = brick("abyss_chiseled", MapColor.COLOR_CYAN);
    public static final RegistryObject<Block> CORAL_LAMP = lamp("coral_lamp", MapColor.COLOR_LIGHT_GREEN);

    // ---- Piramide Solar ----
    public static final RegistryObject<Block> SUN_BRICKS = brick("sun_bricks", MapColor.SAND);
    public static final RegistryObject<Block> SUN_CHISELED = brick("sun_chiseled", MapColor.GOLD);
    public static final RegistryObject<Block> SUN_LAMP = lamp("sun_lamp", MapColor.GOLD);

    private static RegistryObject<Block> brick(String name, MapColor color) {
        return block(name, () -> new Block(BlockBehaviour.Properties.of()
                .mapColor(color).strength(2.5F, 6.0F).requiresCorrectToolForDrops().sound(SoundType.STONE)));
    }

    private static RegistryObject<Block> lamp(String name, MapColor color) {
        return block(name, () -> new Block(BlockBehaviour.Properties.of()
                .mapColor(color).strength(1.0F).sound(SoundType.GLASS).lightLevel(state -> 15)));
    }

    private static RegistryObject<Block> block(String name, Supplier<Block> supplier) {
        RegistryObject<Block> object = BLOCKS.register(name, supplier);
        BLOCK_ITEMS.register(name, () -> new BlockItem(object.get(), new Item.Properties()));
        return object;
    }
}
