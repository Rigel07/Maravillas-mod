# Maravillas del Mundo (Forge 1.20.1)

Cuatro estructuras espectaculares que aparecen solas al explorar, cada una con sus propios guardianes, un jefe, objetos únicos y su propio juego de bloques de construcción.

## Las 4 maravillas
| Estructura | Dónde | Qué hay dentro |
|---|---|---|
| **Torre Estelar** | Bosques, taigas, sabanas y llanuras | Torre de 70 bloques con escalera de caracol, balcones, observatorio con cúpula de cristal y un gran cristal estelar. Jefe: **Archimago Estelar** |
| **Ciudadela Celeste** | Flotando en el cielo (Y 150) sobre cualquier zona del Overworld | Isla flotante con castillo, murallas, 4 torres, fuente, jardines y sala del trono. Jefe: **Guardián de la Tormenta** |
| **Templo Hundido** | Océanos profundos | Zigurat inundado de 4 pisos, pozo central, cámaras de guardianes, cámara seca sellada con tesoro y santuario. Jefe: **Sacerdote del Abismo** |
| **Pirámide Solar** | Desiertos y mesas (badlands) | Pirámide con corredor de trampas (placas + TNT), gran sala, rampa en espiral a la cámara del faraón y haz de sol. Jefe: **Faraón Dorado** |

Para encontrarlas rápido: `/locate structure maravillas:torre_estelar` (también `ciudadela_celeste`, `templo_hundido`, `piramide_solar`), o craftea la **Brújula de las Maravillas**.

## Guardianes (mobs)
Normales: Aprendiz Estelar (dispara balas de shulker), Centinela de Nube (te lanza por los aires), Guardián Coralino (fatiga de minado), Momia Solar (hambre).
Jefes con barra de vida: Archimago (invoca aprendices), Guardián de la Tormenta (rayos), Sacerdote del Abismo (pulso sónico), Faraón (invoca momias, te prende fuego).
Cada guardián suelta el material de su maravilla y los jefes sueltan su objeto único.

## Objetos
- **Báculo Estelar**: rayo de estrellas que atraviesa a todos (jefe de la torre).
- **Tomo del Aprendiz**: +5 niveles de experiencia.
- **Cetro de Tormenta**: invoca un rayo donde miras (jefe de la ciudadela).
- **Pluma Celeste**: caída lenta, velocidad y salto durante 5 minutos.
- **Perla Abisal**: respirar bajo el agua, visión nocturna y gracia del delfín 10 minutos.
- **Corazón de Coral**: en la barra rápida da poder del conducto y gracia del delfín (jefe del templo).
- **Ankh Dorado**: te salva de la muerte una vez, como un tótem (jefe de la pirámide).
- **Brújula de las Maravillas**: te dice hacia dónde está la más cercana.
- Materiales: Fragmento estelar, Núcleo de nube, Esquirla abisal y Escarabajo solar. Con ellos se craftean 4 ladrillos del juego de bloques de cada maravilla, lámparas y más.

## Bloques
12 bloques de construcción (ladrillos, bloque especial y lámpara de cada estructura). Hay huevos de guardián de cada clase en la pestaña creativa.

## Compilar con GitHub (sin descomprimir)
1. Sube el zip del mod tal cual a la raíz de un repositorio nuevo.
2. Crea a mano `.github/workflows/build.yml` con el archivo que acompaña al zip (la carpeta `.github` es oculta y no se sube arrastrando).
3. Actions > último workflow > Artifacts > `maravillas-jar`.
