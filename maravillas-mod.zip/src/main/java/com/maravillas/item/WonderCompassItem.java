package com.maravillas.item;

import com.maravillas.registry.ModTags;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Brujula de las Maravillas: clic derecho indica hacia donde esta la maravilla mas cercana. */
public class WonderCompassItem extends Item {
    public WonderCompassItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && level instanceof ServerLevel server) {
            BlockPos found = server.findNearestMapStructure(ModTags.WONDERS, player.blockPosition(), 64, false);
            if (found == null) {
                player.displayClientMessage(Component.translatable("message.maravillas.compass_none"), true);
                level.playSound(null, player.blockPosition(), SoundEvents.COMPARATOR_CLICK, SoundSource.PLAYERS, 0.6F, 0.6F);
            } else {
                int dx = found.getX() - player.getBlockX();
                int dz = found.getZ() - player.getBlockZ();
                int distance = (int) Math.round(Math.sqrt((double) dx * dx + (double) dz * dz));
                String direction;
                if (Math.abs(dx) > Math.abs(dz)) {
                    direction = dx > 0 ? "east" : "west";
                } else {
                    direction = dz > 0 ? "south" : "north";
                }
                player.displayClientMessage(Component.translatable("message.maravillas.compass_found",
                        distance, Component.translatable("direction.maravillas." + direction)), true);
                level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.5F);
            }
            player.getCooldowns().addCooldown(this, 100);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
