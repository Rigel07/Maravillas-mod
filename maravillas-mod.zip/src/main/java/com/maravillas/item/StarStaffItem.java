package com.maravillas.item;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Baculo Estelar: dispara un rayo de estrellas que atraviesa a todos los que toca. */
public class StarStaffItem extends Item {
    public StarStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && level instanceof ServerLevel server) {
            Vec3 eye = player.getEyePosition();
            Vec3 look = player.getLookAngle();
            Set<LivingEntity> hit = new HashSet<>();
            for (double d = 1.0D; d <= 24.0D; d += 0.6D) {
                Vec3 point = eye.add(look.scale(d));
                BlockPos pos = BlockPos.containing(point);
                if (!server.getBlockState(pos).getCollisionShape(server, pos).isEmpty()) {
                    break;
                }
                server.sendParticles(ParticleTypes.END_ROD, point.x, point.y, point.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                for (LivingEntity target : server.getEntitiesOfClass(LivingEntity.class,
                        new AABB(point, point).inflate(0.8D), e -> e != player && e.isAlive())) {
                    if (hit.add(target)) {
                        target.hurt(server.damageSources().indirectMagic(player, player), 8.0F);
                        target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0));
                    }
                }
            }
            level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.PLAYERS, 1.2F, 1.4F);
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            player.getCooldowns().addCooldown(this, 25);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
