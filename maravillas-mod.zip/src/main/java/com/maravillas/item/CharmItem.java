package com.maravillas.item;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Amuleto: en la barra rapida (o la mano izquierda) da efectos pasivos. */
public class CharmItem extends Item {
    private final Supplier<List<MobEffectInstance>> effects;

    public CharmItem(Properties properties, Supplier<List<MobEffectInstance>> effects) {
        super(properties);
        this.effects = effects;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (!level.isClientSide && entity instanceof Player player
                && (slot < 9 || slot == 40) && level.getGameTime() % 40 == 0) {
            for (MobEffectInstance effect : this.effects.get()) {
                player.addEffect(new MobEffectInstance(effect));
            }
        }
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
