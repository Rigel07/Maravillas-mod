package com.maravillas.item;

import com.maravillas.entity.MobKind;
import com.maravillas.entity.WonderMob;
import com.maravillas.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Huevo de guardian: hace aparecer un guardian de una clase concreta. */
public class WonderEggItem extends Item {
    private final MobKind kind;

    public WonderEggItem(MobKind kind, Properties properties) {
        super(properties);
        this.kind = kind;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!(level instanceof ServerLevel server)) {
            return InteractionResult.SUCCESS;
        }
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        WonderMob mob = ModEntities.WONDER_MOB.get().create(server);
        if (mob == null) {
            return InteractionResult.FAIL;
        }
        mob.setKind(this.kind, true);
        mob.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, server.random.nextFloat() * 360.0F, 0.0F);
        mob.finalizeSpawn(server, server.getCurrentDifficultyAt(pos), MobSpawnType.SPAWN_EGG, null, null);
        server.addFreshEntity(mob);
        if (context.getPlayer() == null || !context.getPlayer().getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }
}
