package com.maravillas.registry;

import com.maravillas.MaravillasMod;
import com.maravillas.entity.WonderMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MaravillasMod.MODID);

    /** Un unico tipo de entidad; cada guardian es una "clase" (MobKind). */
    public static final RegistryObject<EntityType<WonderMob>> WONDER_MOB = ENTITIES.register("wonder_mob",
            () -> EntityType.Builder.<WonderMob>of(WonderMob::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.25F)
                    .clientTrackingRange(10)
                    .build("wonder_mob"));
}
