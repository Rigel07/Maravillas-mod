package com.maravillas.registry;

import com.maravillas.MaravillasMod;
import com.maravillas.entity.MobKind;
import com.maravillas.item.ApprenticeTomeItem;
import com.maravillas.item.CharmItem;
import com.maravillas.item.EffectConsumableItem;
import com.maravillas.item.StarStaffItem;
import com.maravillas.item.StormScepterItem;
import com.maravillas.item.WonderCompassItem;
import com.maravillas.item.WonderEggItem;
import java.util.List;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MaravillasMod.MODID);

    // ---- Materiales (los sueltan los guardianes) ----
    public static final RegistryObject<Item> STAR_FRAGMENT = material("star_fragment", Rarity.UNCOMMON);
    public static final RegistryObject<Item> CLOUD_CORE = material("cloud_core", Rarity.UNCOMMON);
    public static final RegistryObject<Item> ABYSS_SHARD = material("abyss_shard", Rarity.UNCOMMON);
    public static final RegistryObject<Item> SUN_SCARAB = material("sun_scarab", Rarity.UNCOMMON);

    // ---- Torre Estelar ----
    public static final RegistryObject<Item> STAR_STAFF = ITEMS.register("star_staff",
            () -> new StarStaffItem(new Item.Properties().durability(120).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> APPRENTICE_TOME = ITEMS.register("apprentice_tome",
            () -> new ApprenticeTomeItem(new Item.Properties().stacksTo(16).rarity(Rarity.RARE)));

    // ---- Ciudadela Celeste ----
    public static final RegistryObject<Item> STORM_SCEPTER = ITEMS.register("storm_scepter",
            () -> new StormScepterItem(new Item.Properties().durability(80).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> SKY_FEATHER = ITEMS.register("sky_feather",
            () -> new EffectConsumableItem(new Item.Properties().stacksTo(16).rarity(Rarity.RARE), () -> List.of(
                    new MobEffectInstance(MobEffects.SLOW_FALLING, 6000, 0),
                    new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 6000, 1),
                    new MobEffectInstance(MobEffects.JUMP, 6000, 1))));

    // ---- Templo Hundido ----
    public static final RegistryObject<Item> ABYSS_PEARL = ITEMS.register("abyss_pearl",
            () -> new EffectConsumableItem(new Item.Properties().stacksTo(16).rarity(Rarity.RARE), () -> List.of(
                    new MobEffectInstance(MobEffects.WATER_BREATHING, 12000, 0),
                    new MobEffectInstance(MobEffects.NIGHT_VISION, 12000, 0),
                    new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 12000, 0))));
    public static final RegistryObject<Item> CORAL_HEART = ITEMS.register("coral_heart",
            () -> new CharmItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC), () -> List.of(
                    new MobEffectInstance(MobEffects.CONDUIT_POWER, 100, 0, true, false, true),
                    new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 100, 0, true, false, true))));

    // ---- Piramide Solar ----
    /** Como un totem: te salva de la muerte una vez (ver GameEvents). */
    public static final RegistryObject<Item> GOLDEN_ANKH = ITEMS.register("golden_ankh",
            () -> new Item(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    // ---- Utilidad ----
    public static final RegistryObject<Item> WONDER_COMPASS = ITEMS.register("wonder_compass",
            () -> new WonderCompassItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON)));

    // ---- Huevos de guardian (uno por clase) ----
    static {
        for (MobKind kind : MobKind.values()) {
            ITEMS.register(kind.id() + "_egg", () -> new WonderEggItem(kind, new Item.Properties()));
        }
    }

    private static RegistryObject<Item> material(String name, Rarity rarity) {
        return ITEMS.register(name, () -> new Item(new Item.Properties().rarity(rarity)));
    }
}
