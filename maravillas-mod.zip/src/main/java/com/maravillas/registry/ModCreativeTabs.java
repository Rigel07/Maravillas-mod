package com.maravillas.registry;

import com.maravillas.MaravillasMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MaravillasMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("maravillas",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.maravillas"))
                    .icon(() -> new ItemStack(ModItems.WONDER_COMPASS.get()))
                    .displayItems((parameters, output) -> {
                        ModItems.ITEMS.getEntries().forEach(item -> output.accept(item.get()));
                        ModBlocks.BLOCK_ITEMS.getEntries().forEach(item -> output.accept(item.get()));
                    })
                    .build());
}
