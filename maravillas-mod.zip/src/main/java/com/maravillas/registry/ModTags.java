package com.maravillas.registry;

import com.maravillas.MaravillasMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.levelgen.structure.Structure;

public class ModTags {
    /** Las cuatro maravillas: la brujula las busca. */
    public static final TagKey<Structure> WONDERS =
            TagKey.create(Registries.STRUCTURE, new ResourceLocation(MaravillasMod.MODID, "wonders"));
}
