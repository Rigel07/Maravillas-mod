package com.maravillas.event;

import com.maravillas.MaravillasMod;
import com.maravillas.entity.WonderMob;
import com.maravillas.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MaravillasMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.WONDER_MOB.get(), WonderMob.createAttributes().build());
    }
}
