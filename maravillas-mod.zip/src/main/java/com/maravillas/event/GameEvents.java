package com.maravillas.event;

import com.maravillas.MaravillasMod;
import com.maravillas.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MaravillasMod.MODID)
public class GameEvents {

    /** El Ankh Dorado te salva de morir una vez (menos del vacio o /kill), como un totem. */
    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)
                || event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        ItemStack ankh = ItemStack.EMPTY;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(ModItems.GOLDEN_ANKH.get())) {
                ankh = stack;
                break;
            }
        }
        if (ankh.isEmpty() && player.getOffhandItem().is(ModItems.GOLDEN_ANKH.get())) {
            ankh = player.getOffhandItem();
        }
        if (ankh.isEmpty()) {
            return;
        }
        ankh.shrink(1);
        event.setCanceled(true);
        player.setHealth(10.0F);
        player.removeAllEffects();
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 900, 1));
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 800, 0));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 100, 1));
        player.level().broadcastEntityEvent(player, (byte) 35);
        player.displayClientMessage(Component.translatable("message.maravillas.ankh"), true);
    }
}
