package com.maravillas;

import com.maravillas.registry.ModBlocks;
import com.maravillas.registry.ModCreativeTabs;
import com.maravillas.registry.ModEntities;
import com.maravillas.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MaravillasMod.MODID)
public class MaravillasMod {
    public static final String MODID = "maravillas";

    public MaravillasMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModBlocks.BLOCK_ITEMS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
