package com.maravillas.entity;

import java.util.function.Supplier;
import net.minecraft.world.BossEvent;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/**
 * Los 8 guardianes de las estructuras: uno normal y un jefe por estructura.
 * La forma y el sombrero se activan con banderas (ver Parts).
 */
public enum MobKind {
    STAR_APPRENTICE("star_apprentice", 24, 3, 0.26, 1.0F, false, Ranged.SHULKER, Parts.BRIM | Parts.CROWN | Parts.CONE2 | Parts.CONE3, () -> Items.BLAZE_ROD, false, BossEvent.BossBarColor.PURPLE),
    STAR_ARCHMAGE("star_archmage", 160, 7, 0.28, 1.5F, true, Ranged.SHULKER, Parts.BRIM | Parts.CROWN | Parts.CONE2 | Parts.CONE3 | Parts.CAPE, () -> Items.AMETHYST_SHARD, false, BossEvent.BossBarColor.PURPLE),
    CLOUD_SENTINEL("cloud_sentinel", 50, 6, 0.25, 1.0F, false, Ranged.NONE, Parts.HELMET | Parts.PLUME, () -> Items.IRON_SWORD, false, BossEvent.BossBarColor.WHITE),
    STORM_WARDEN("storm_warden", 180, 9, 0.27, 1.5F, true, Ranged.NONE, Parts.HELMET | Parts.PLUME | Parts.CAPE, () -> Items.GOLDEN_AXE, false, BossEvent.BossBarColor.BLUE),
    CORAL_GUARDIAN("coral_guardian", 40, 5, 0.24, 1.0F, false, Ranged.NONE, Parts.SPIKES, () -> Items.TRIDENT, true, BossEvent.BossBarColor.GREEN),
    ABYSS_PRIEST("abyss_priest", 150, 6, 0.26, 1.5F, true, Ranged.NONE, Parts.HOOD | Parts.CAPE, () -> Items.PRISMARINE_SHARD, true, BossEvent.BossBarColor.GREEN),
    SUN_MUMMY("sun_mummy", 30, 5, 0.23, 1.0F, false, Ranged.NONE, Parts.CAP, () -> Items.AIR, false, BossEvent.BossBarColor.YELLOW),
    PHARAOH("pharaoh", 170, 8, 0.25, 1.5F, true, Ranged.NONE, Parts.CROWN | Parts.PLUME | Parts.CAPE, () -> Items.GOLDEN_HOE, false, BossEvent.BossBarColor.YELLOW);

    public enum Ranged { NONE, SHULKER }

    /** Piezas opcionales del modelo, como banderas. */
    public static final class Parts {
        public static final int CAPE = 1;
        public static final int BRIM = 1 << 1;
        public static final int CROWN = 1 << 2;
        public static final int CONE2 = 1 << 3;
        public static final int CONE3 = 1 << 4;
        public static final int HELMET = 1 << 5;
        public static final int PLUME = 1 << 6;
        public static final int CAP = 1 << 7;
        public static final int HOOD = 1 << 8;
        public static final int SPIKES = 1 << 9;

        private Parts() {}
    }

    private final String id;
    private final double health;
    private final double damage;
    private final double speed;
    private final float scale;
    private final boolean boss;
    private final Ranged ranged;
    private final int parts;
    private final Supplier<Item> mainHand;
    private final boolean aquatic;
    private final BossEvent.BossBarColor barColor;

    MobKind(String id, double health, double damage, double speed, float scale, boolean boss, Ranged ranged,
            int parts, Supplier<Item> mainHand, boolean aquatic, BossEvent.BossBarColor barColor) {
        this.id = id;
        this.health = health;
        this.damage = damage;
        this.speed = speed;
        this.scale = scale;
        this.boss = boss;
        this.ranged = ranged;
        this.parts = parts;
        this.mainHand = mainHand;
        this.aquatic = aquatic;
        this.barColor = barColor;
    }

    public String id() { return this.id; }
    public double health() { return this.health; }
    public double damage() { return this.damage; }
    public double speed() { return this.speed; }
    public float scale() { return this.scale; }
    public boolean boss() { return this.boss; }
    public Ranged ranged() { return this.ranged; }
    public boolean has(int part) { return (this.parts & part) != 0; }
    public Item mainHand() { return this.mainHand.get(); }
    public boolean aquatic() { return this.aquatic; }
    public BossEvent.BossBarColor barColor() { return this.barColor; }

    public static MobKind byIndex(int index) {
        MobKind[] all = values();
        return all[Math.floorMod(index, all.length)];
    }

    public static MobKind byName(String name) {
        for (MobKind kind : values()) {
            if (kind.id.equals(name)) {
                return kind;
            }
        }
        return null;
    }
}
