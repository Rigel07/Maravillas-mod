package com.maravillas.entity;

import com.maravillas.registry.ModEntities;
import com.maravillas.registry.ModItems;
import javax.annotation.Nullable;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ShulkerBullet;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.pathfinder.BlockPathTypes;

/**
 * Guardian de una maravilla. Un solo tipo de entidad con 8 "clases" (MobKind):
 * un guardian normal y un jefe por estructura, cada uno con su habilidad.
 */
public class WonderMob extends Monster implements RangedAttackMob {
    private static final EntityDataAccessor<Integer> DATA_KIND =
            SynchedEntityData.defineId(WonderMob.class, EntityDataSerializers.INT);

    private ServerBossEvent bossEvent =
            new ServerBossEvent(Component.empty(), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
    private int specialTimer = 200;

    public WonderMob(EntityType<? extends WonderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 24.0D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.ARMOR, 0.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.0D);
    }

    // ----------------------------------------------------------------- Clase

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_KIND, 0);
    }

    public MobKind getKind() {
        return MobKind.byIndex(this.entityData.get(DATA_KIND));
    }

    public void setKind(MobKind kind, boolean fullHealth) {
        this.entityData.set(DATA_KIND, kind.ordinal());
        this.applyKind(fullHealth);
    }

    private void applyKind(boolean fullHealth) {
        MobKind kind = this.getKind();
        this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(kind.health());
        this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(kind.damage());
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(kind.speed());
        boolean armored = kind == MobKind.CLOUD_SENTINEL || kind == MobKind.STORM_WARDEN;
        this.getAttribute(Attributes.ARMOR).setBaseValue(armored ? 6.0D : 0.0D);
        this.getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(kind.boss() ? 0.6D : 0.0D);
        if (fullHealth) {
            this.setHealth(this.getMaxHealth());
        }
        Item hand = kind.mainHand();
        this.setItemSlot(EquipmentSlot.MAINHAND, hand == Items.AIR ? ItemStack.EMPTY : new ItemStack(hand));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        this.setPathfindingMalus(BlockPathTypes.WATER, kind.aquatic() ? 0.0F : 8.0F);
        this.bossEvent.removeAllPlayers();
        this.bossEvent = new ServerBossEvent(this.getDisplayName(), kind.barColor(), BossEvent.BossBarOverlay.PROGRESS);
        this.refreshDimensions();
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        this.applyKind(true);
        if (reason == MobSpawnType.STRUCTURE || this.getKind().boss()) {
            this.setPersistenceRequired();
        }
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public Component getTypeName() {
        return Component.translatable("entity.maravillas." + this.getKind().id());
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return super.getDimensions(pose).scale(this.getKind().scale());
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (DATA_KIND.equals(key)) {
            this.refreshDimensions();
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("Kind", this.getKind().id());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        MobKind kind = MobKind.byName(tag.getString("Kind"));
        if (kind != null) {
            this.entityData.set(DATA_KIND, kind.ordinal());
        }
        this.applyKind(false);
        if (tag.contains("Health", 99)) {
            this.setHealth(tag.getFloat("Health"));
        } else {
            this.setHealth(this.getMaxHealth());
        }
    }

    // -------------------------------------------------------------------- IA

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this) {
            @Override
            public boolean canUse() {
                return !WonderMob.this.getKind().aquatic() && super.canUse();
            }
        });
        this.goalSelector.addGoal(2, new RangedAttackGoal(this, 1.0D, 50, 18.0F) {
            @Override
            public boolean canUse() {
                return WonderMob.this.getKind().ranged() == MobKind.Ranged.SHULKER && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return WonderMob.this.getKind().ranged() == MobKind.Ranged.SHULKER && super.canContinueToUse();
            }
        });
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.15D, true) {
            @Override
            public boolean canUse() {
                return WonderMob.this.getKind().ranged() == MobKind.Ranged.NONE && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return WonderMob.this.getKind().ranged() == MobKind.Ranged.NONE && super.canContinueToUse();
            }
        });
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void performRangedAttack(LivingEntity target, float power) {
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }
        int bullets = this.getKind().boss() ? 3 : 1;
        for (int i = 0; i < bullets; i++) {
            server.addFreshEntity(new ShulkerBullet(server, this, target, Direction.Axis.Y));
        }
        this.playSound(SoundEvents.SHULKER_SHOOT, 2.0F, 0.8F + this.random.nextFloat() * 0.4F);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity living) {
            switch (this.getKind()) {
                case CLOUD_SENTINEL, STORM_WARDEN -> {
                    living.setDeltaMovement(living.getDeltaMovement().add(0.0D, 0.55D, 0.0D));
                    living.hurtMarked = true;
                }
                case CORAL_GUARDIAN -> living.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 200, 1));
                case SUN_MUMMY -> living.addEffect(new MobEffectInstance(MobEffects.HUNGER, 200, 1));
                case PHARAOH -> living.setSecondsOnFire(6);
                default -> { }
            }
        }
        return hit;
    }

    // ------------------------------------------------------------ Habilidades

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            return;
        }
        if (this.getKind().boss()) {
            this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
        }
        LivingEntity target = this.getTarget();
        if (target != null && target.isAlive() && this.getKind().boss()) {
            if (--this.specialTimer <= 0) {
                this.useSpecial(target);
            }
        }
    }

    private void useSpecial(LivingEntity target) {
        switch (this.getKind()) {
            case STAR_ARCHMAGE -> {
                this.summon(MobKind.STAR_APPRENTICE, 2, 24.0D, 4);
                this.specialTimer = 400;
            }
            case STORM_WARDEN -> {
                if (this.distanceToSqr(target) < 576.0D) {
                    this.strike(target);
                }
                this.specialTimer = 140;
            }
            case ABYSS_PRIEST -> {
                if (this.distanceToSqr(target) < 196.0D) {
                    this.pulse(target);
                }
                this.specialTimer = 100;
            }
            case PHARAOH -> {
                this.summon(MobKind.SUN_MUMMY, 2, 24.0D, 4);
                this.specialTimer = 400;
            }
            default -> this.specialTimer = 1000;
        }
    }

    private void summon(MobKind kind, int count, double radius, int maxNearby) {
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }
        int near = server.getEntitiesOfClass(WonderMob.class, this.getBoundingBox().inflate(radius),
                m -> m.getKind() == kind && m.isAlive()).size();
        if (near >= maxNearby) {
            return;
        }
        for (int i = 0; i < count; i++) {
            WonderMob minion = ModEntities.WONDER_MOB.get().create(server);
            if (minion == null) {
                continue;
            }
            minion.setKind(kind, true);
            minion.moveTo(this.getX() + (this.random.nextDouble() - 0.5D) * 4.0D, this.getY(),
                    this.getZ() + (this.random.nextDouble() - 0.5D) * 4.0D, this.random.nextFloat() * 360.0F, 0.0F);
            server.addFreshEntity(minion);
            server.sendParticles(ParticleTypes.POOF, minion.getX(), minion.getY() + 0.8D, minion.getZ(),
                    10, 0.3D, 0.5D, 0.3D, 0.02D);
        }
        this.playSound(SoundEvents.EVOKER_PREPARE_SUMMON, 1.0F, 1.0F);
    }

    private void strike(LivingEntity target) {
        if (!(this.level() instanceof ServerLevel server)) {
            return;
        }
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(server);
        if (bolt != null) {
            bolt.moveTo(target.getX(), target.getY(), target.getZ());
            bolt.setVisualOnly(true);
            server.addFreshEntity(bolt);
        }
        target.hurt(this.damageSources().lightningBolt(), 8.0F);
        target.setSecondsOnFire(3);
    }

    private void pulse(LivingEntity target) {
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.SONIC_BOOM, target.getX(), target.getEyeY(), target.getZ(),
                    1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        this.playSound(SoundEvents.WARDEN_SONIC_BOOM, 1.0F, 1.3F);
        target.hurt(this.damageSources().magic(), 5.0F);
        target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 80, 0));
        target.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 200, 1));
        target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1));
    }

    // ----------------------------------------------------------- Jefes y botin

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        if (this.getKind().boss()) {
            this.bossEvent.addPlayer(player);
        }
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean fireImmune() {
        return this.getKind() == MobKind.PHARAOH || super.fireImmune();
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        if (this.getKind() == MobKind.PHARAOH && source.is(net.minecraft.tags.DamageTypeTags.IS_FIRE)) {
            return true;
        }
        return super.isInvulnerableTo(source);
    }

    @Override
    public boolean canBreatheUnderwater() {
        return this.getKind().aquatic() || super.canBreatheUnderwater();
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        if (this.getKind() == MobKind.CLOUD_SENTINEL || this.getKind() == MobKind.STORM_WARDEN) {
            return false;
        }
        return super.causeFallDamage(distance, multiplier, source);
    }

    @Override
    protected float getWaterSlowDown() {
        return this.getKind().aquatic() ? 0.95F : super.getWaterSlowDown();
    }

    @Override
    protected int getExperienceReward() {
        return this.getKind().boss() ? 60 : 8;
    }

    private Item material() {
        return switch (this.getKind()) {
            case STAR_APPRENTICE, STAR_ARCHMAGE -> ModItems.STAR_FRAGMENT.get();
            case CLOUD_SENTINEL, STORM_WARDEN -> ModItems.CLOUD_CORE.get();
            case CORAL_GUARDIAN, ABYSS_PRIEST -> ModItems.ABYSS_SHARD.get();
            case SUN_MUMMY, PHARAOH -> ModItems.SUN_SCARAB.get();
        };
    }

    @Nullable
    private Item bossDrop() {
        return switch (this.getKind()) {
            case STAR_ARCHMAGE -> ModItems.STAR_STAFF.get();
            case STORM_WARDEN -> ModItems.STORM_SCEPTER.get();
            case ABYSS_PRIEST -> ModItems.CORAL_HEART.get();
            case PHARAOH -> ModItems.GOLDEN_ANKH.get();
            default -> null;
        };
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        if (this.getKind().boss()) {
            Item drop = this.bossDrop();
            if (drop != null) {
                this.spawnAtLocation(new ItemStack(drop));
            }
            this.spawnAtLocation(new ItemStack(this.material(), 2 + this.random.nextInt(3)));
        } else if (this.random.nextInt(100) < 25 + looting * 10) {
            this.spawnAtLocation(new ItemStack(this.material()));
        }
    }

    // ---------------------------------------------------------------- Sonidos

    @Override
    protected SoundEvent getAmbientSound() {
        return switch (this.getKind()) {
            case SUN_MUMMY, PHARAOH -> SoundEvents.HUSK_AMBIENT;
            case CORAL_GUARDIAN, ABYSS_PRIEST -> SoundEvents.DROWNED_AMBIENT;
            case STAR_APPRENTICE, STAR_ARCHMAGE -> SoundEvents.EVOKER_AMBIENT;
            default -> SoundEvents.VINDICATOR_AMBIENT;
        };
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return switch (this.getKind()) {
            case SUN_MUMMY, PHARAOH -> SoundEvents.HUSK_HURT;
            case CORAL_GUARDIAN, ABYSS_PRIEST -> SoundEvents.DROWNED_HURT;
            case STAR_APPRENTICE, STAR_ARCHMAGE -> SoundEvents.EVOKER_HURT;
            default -> SoundEvents.IRON_GOLEM_HURT;
        };
    }

    @Override
    protected SoundEvent getDeathSound() {
        return switch (this.getKind()) {
            case SUN_MUMMY, PHARAOH -> SoundEvents.HUSK_DEATH;
            case CORAL_GUARDIAN, ABYSS_PRIEST -> SoundEvents.DROWNED_DEATH;
            case STAR_APPRENTICE, STAR_ARCHMAGE -> SoundEvents.EVOKER_DEATH;
            default -> SoundEvents.IRON_GOLEM_DEATH;
        };
    }
}
