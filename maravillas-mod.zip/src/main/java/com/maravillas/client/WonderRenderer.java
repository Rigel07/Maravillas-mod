package com.maravillas.client;

import com.maravillas.MaravillasMod;
import com.maravillas.entity.WonderMob;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

public class WonderRenderer extends MobRenderer<WonderMob, WonderModel<WonderMob>> {
    public WonderRenderer(EntityRendererProvider.Context context) {
        super(context, new WonderModel<>(context.bakeLayer(WonderModel.LAYER_LOCATION)), 0.4F);
        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(WonderMob entity) {
        return new ResourceLocation(MaravillasMod.MODID, "textures/entity/" + entity.getKind().id() + ".png");
    }

    @Override
    protected void scale(WonderMob entity, PoseStack poseStack, float partialTick) {
        float size = entity.getKind().scale();
        poseStack.scale(size, size, size);
    }
}
