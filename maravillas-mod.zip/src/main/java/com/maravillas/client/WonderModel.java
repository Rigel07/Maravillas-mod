package com.maravillas.client;

import com.maravillas.MaravillasMod;
import com.maravillas.entity.MobKind;
import com.maravillas.entity.MobKind.Parts;
import com.maravillas.entity.WonderMob;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.ArmedModel;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/** Cuerpo chibi de los guardianes, con sombreros y adornos segun la clase. Textura 64x160. */
public class WonderModel<T extends WonderMob> extends EntityModel<T> implements ArmedModel {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(MaravillasMod.MODID, "wonder_mob"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;
    private final ModelPart cape, brim, crown, cone2, cone3, helmet, plume, cap, hood, spikes;

    public WonderModel(ModelPart root) {
        this.root = root;
        ModelPart model = root.getChild("model");
        this.head = model.getChild("head");
        this.rightArm = model.getChild("right_arm");
        this.leftArm = model.getChild("left_arm");
        this.rightLeg = model.getChild("right_leg");
        this.leftLeg = model.getChild("left_leg");
        this.cape = model.getChild("body").getChild("cape");
        this.brim = this.head.getChild("brim");
        this.crown = this.head.getChild("crown");
        this.cone2 = this.head.getChild("cone2");
        this.cone3 = this.head.getChild("cone3");
        this.helmet = this.head.getChild("helmet");
        this.plume = this.head.getChild("plume");
        this.cap = this.head.getChild("cap");
        this.hood = this.head.getChild("hood");
        this.spikes = this.head.getChild("spikes");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition model = root.addOrReplaceChild("model", CubeListBuilder.create(), PartPose.ZERO);

        PartDefinition head = model.addOrReplaceChild("head", CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 12.0F, 0.0F));
        PartDefinition body = model.addOrReplaceChild("body", CubeListBuilder.create()
                        .texOffs(16, 16).addBox(-3.0F, -7.0F, -2.0F, 6.0F, 7.0F, 4.0F),
                PartPose.offset(0.0F, 19.0F, 0.0F));
        model.addOrReplaceChild("right_arm", CubeListBuilder.create()
                        .texOffs(40, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offset(-4.0F, 13.0F, 0.0F));
        model.addOrReplaceChild("left_arm", CubeListBuilder.create()
                        .texOffs(40, 16).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offset(4.0F, 13.0F, 0.0F));
        model.addOrReplaceChild("right_leg", CubeListBuilder.create()
                        .texOffs(0, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offset(-1.5F, 19.0F, 0.0F));
        model.addOrReplaceChild("left_leg", CubeListBuilder.create()
                        .texOffs(0, 16).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 5.0F, 2.0F),
                PartPose.offset(1.5F, 19.0F, 0.0F));

        body.addOrReplaceChild("cape", CubeListBuilder.create()
                .texOffs(0, 32).addBox(-4.0F, -7.0F, 2.0F, 8.0F, 9.0F, 1.0F), PartPose.ZERO);

        head.addOrReplaceChild("brim", CubeListBuilder.create()
                .texOffs(0, 44).addBox(-5.5F, -8.4F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.ZERO);
        head.addOrReplaceChild("crown", CubeListBuilder.create()
                .texOffs(0, 57).addBox(-4.0F, -11.2F, -4.0F, 8.0F, 3.0F, 8.0F), PartPose.ZERO);
        head.addOrReplaceChild("cone2", CubeListBuilder.create()
                .texOffs(34, 57).addBox(-3.0F, -14.2F, -3.0F, 6.0F, 3.0F, 6.0F), PartPose.ZERO);
        head.addOrReplaceChild("cone3", CubeListBuilder.create()
                .texOffs(46, 44).addBox(-1.5F, -17.2F, -1.5F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);
        head.addOrReplaceChild("helmet", CubeListBuilder.create()
                .texOffs(0, 70).addBox(-4.5F, -9.0F, -4.5F, 9.0F, 5.0F, 9.0F), PartPose.ZERO);
        head.addOrReplaceChild("plume", CubeListBuilder.create()
                .texOffs(38, 70).addBox(-0.5F, -13.0F, -2.0F, 1.0F, 4.0F, 4.0F), PartPose.ZERO);
        head.addOrReplaceChild("cap", CubeListBuilder.create()
                .texOffs(0, 86).addBox(-4.5F, -9.0F, -4.5F, 9.0F, 2.0F, 9.0F), PartPose.ZERO);
        head.addOrReplaceChild("hood", CubeListBuilder.create()
                .texOffs(0, 98).addBox(-4.5F, -9.0F, -1.5F, 9.0F, 9.0F, 6.0F), PartPose.ZERO);
        head.addOrReplaceChild("spikes", CubeListBuilder.create()
                .texOffs(46, 44)
                .addBox(-4.5F, -10.5F, -1.5F, 3.0F, 3.0F, 3.0F)
                .addBox(-1.5F, -12.0F, -1.5F, 3.0F, 3.0F, 3.0F)
                .addBox(1.5F, -10.5F, -1.5F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 160);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        MobKind kind = entity.getKind();
        this.cape.visible = kind.has(Parts.CAPE);
        this.brim.visible = kind.has(Parts.BRIM);
        this.crown.visible = kind.has(Parts.CROWN);
        this.cone2.visible = kind.has(Parts.CONE2);
        this.cone3.visible = kind.has(Parts.CONE3);
        this.helmet.visible = kind.has(Parts.HELMET);
        this.plume.visible = kind.has(Parts.PLUME);
        this.cap.visible = kind.has(Parts.CAP);
        this.hood.visible = kind.has(Parts.HOOD);
        this.spikes.visible = kind.has(Parts.SPIKES);

        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.head.xRot = headPitch * ((float) Math.PI / 180F);

        float swing = limbSwing * 0.6662F;
        this.rightArm.xRot = Mth.cos(swing + (float) Math.PI) * 1.2F * limbSwingAmount;
        this.leftArm.xRot = Mth.cos(swing) * 1.2F * limbSwingAmount;
        this.rightLeg.xRot = Mth.cos(swing) * 1.4F * limbSwingAmount;
        this.leftLeg.xRot = Mth.cos(swing + (float) Math.PI) * 1.4F * limbSwingAmount;
        this.rightArm.zRot = 0.06F + Mth.sin(ageInTicks * 0.067F) * 0.05F;
        this.leftArm.zRot = -0.06F - Mth.sin(ageInTicks * 0.067F) * 0.05F;

        // En combate levantan los brazos (hechizo o golpe)
        if (entity.isAggressive()) {
            float cast = -1.3F + Mth.sin(ageInTicks * 0.3F) * 0.15F;
            this.rightArm.xRot = cast;
            this.leftArm.xRot = cast;
        } else if (!entity.getMainHandItem().isEmpty()) {
            this.rightArm.xRot -= 0.35F;
        }
        this.cape.xRot = 0.05F + Math.abs(limbSwingAmount) * 0.25F;
    }

    @Override
    public void translateToHand(HumanoidArm arm, PoseStack poseStack) {
        (arm == HumanoidArm.LEFT ? this.leftArm : this.rightArm).translateAndRotate(poseStack);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
